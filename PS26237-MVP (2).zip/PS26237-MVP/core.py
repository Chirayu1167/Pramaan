"""MVP business logic: recipients, encrypt-once, decrypt+watermark+sign, investigate."""
import secrets
import uuid
from datetime import datetime, timezone

import ledger as ledger_mod
import pqc
import store
import symcrypto
import watermark
import watermark_text

DEMO_RECIPIENTS = ["RECIPIENT-A", "RECIPIENT-B", "RECIPIENT-C"]
MAX_PDF_BYTES = 15 * 1024 * 1024
# --- .txt/.md leaked-document support (additive; PDF path above is untouched) ---
TEXT_EXTENSIONS = (".txt", ".md")
MAX_TEXT_BYTES = 5 * 1024 * 1024

# Passphrase protecting private keys at rest (data/keys/, see store.py).
# This MVP's demo flows (CLI demo, web UI, tests) run fully offline and
# non-interactively, so they rely on this fixed default; any caller doing
# its own key custody should pass an explicit passphrase instead.
DEMO_PASSPHRASE = "ps26237-demo-passphrase"


def utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def validate_pdf(data: bytes, field: str = "file") -> None:
    if not data:
        raise ValueError(f"{field}: empty file")
    if len(data) > MAX_PDF_BYTES:
        raise ValueError(f"{field}: exceeds {MAX_PDF_BYTES} bytes")
    if not data.startswith(b"%PDF"):
        raise ValueError(f"{field}: not a PDF (missing %PDF magic)")


# ---- .txt/.md validation (mirrors validate_pdf's shape; additive) ----
def is_text_document(filename: str) -> bool:
    """True if filename names a plain-text/.md document — i.e. it should go
    through the dual-channel text watermark path instead of the PDF one."""
    return (filename or "").lower().endswith(TEXT_EXTENSIONS)


def validate_text(data: bytes, field: str = "file") -> None:
    if not data:
        raise ValueError(f"{field}: empty file")
    if len(data) > MAX_TEXT_BYTES:
        raise ValueError(f"{field}: exceeds {MAX_TEXT_BYTES} bytes")
    try:
        data.decode("utf-8")
    except UnicodeDecodeError as e:
        raise ValueError(f"{field}: not valid UTF-8 text") from e


def validate_document(data: bytes, filename: str, field: str = "file") -> None:
    """Dispatch to the PDF or text validator by filename extension."""
    if is_text_document(filename):
        validate_text(data, field)
    else:
        validate_pdf(data, field)


# ---- recipients ----
def init_demo_recipients(passphrase: str = DEMO_PASSPHRASE) -> dict:
    """Create the 3 demo recipients with fresh ML-KEM + ML-DSA keypairs."""
    if store.load_ledger():
        raise ValueError(
            "ledger already holds signed events: re-initializing keys would orphan "
            "existing signatures. Run the full demo (which resets state) instead.")
    recips = store.load_recipients()
    for rid in DEMO_RECIPIENTS:
        kem_pk, kem_sk = pqc.kem_generate_keypair()
        dsa_pk, dsa_sk = pqc.dsa_generate_keypair()
        store.save_private_keys(rid, kem_sk, dsa_sk, passphrase)
        recips[rid] = {
            "kem_pk_hex": kem_pk.hex(),
            "dsa_pk_hex": dsa_pk.hex(),
            "kem_alg": pqc.KEM_ALGORITHM,
            "dsa_alg": pqc.DSA_ALGORITHM,
            "created_at": utcnow_iso(),
        }
    store.save_recipients(recips)
    return public_recipients()


def public_recipients() -> dict:
    """Recipients safe for the UI (public keys only — never private keys)."""
    return store.load_recipients()


# ---- encrypt once ----
def encrypt_document(pdf_bytes: bytes, filename: str) -> dict:
    validate_document(pdf_bytes, filename)
    recips = store.load_recipients()
    if not recips:
        raise ValueError("no recipients enrolled — initialize recipients first")
    doc_key = symcrypto.random_bytes(32)
    doc_nonce, doc_ct = symcrypto.aesgcm_encrypt(doc_key, pdf_bytes)
    doc_hash = symcrypto.sha256_hex(pdf_bytes)
    doc_id = uuid.uuid4().hex
    envelopes = {}
    for rid, r in recips.items():
        kem_ct, ss = pqc.kem_encaps(bytes.fromhex(r["kem_pk_hex"]))
        wrap_nonce, wrapped = symcrypto.aesgcm_encrypt(ss, doc_key)
        envelopes[rid] = {
            "kem_ct_hex": kem_ct.hex(),
            "wrap_nonce_hex": wrap_nonce.hex(),
            "wrapped_key_hex": wrapped.hex(),
            "kem_alg": pqc.KEM_ALGORITHM,
        }
    ct_file = store.save_blob(f"{doc_id}.bin", doc_ct)
    docs = store.load_documents()
    docs[doc_id] = {
        "doc_id": doc_id,
        "filename": filename,
        "document_hash": doc_hash,
        "doc_nonce_hex": doc_nonce.hex(),
        "ciphertext_file": ct_file,
        "envelopes": envelopes,
        "created_at": utcnow_iso(),
    }
    store.save_documents(docs)
    return {"doc_id": doc_id, "filename": filename, "document_hash": doc_hash,
            "recipients": sorted(envelopes)}


# ---- decrypt + watermark + sign + ledger ----
def decrypt_for_recipient(doc_id: str, recipient_id: str, passphrase: str = DEMO_PASSPHRASE) -> dict:
    docs = store.load_documents()
    doc = docs.get(doc_id)
    if doc is None:
        raise ValueError("unknown document")
    if recipient_id not in doc["envelopes"]:
        raise ValueError("recipient has no access to this document")
    kem_sk, dsa_sk = store.load_private_keys(recipient_id, passphrase)
    env = doc["envelopes"][recipient_id]
    ss = pqc.kem_decaps(kem_sk, bytes.fromhex(env["kem_ct_hex"]))
    doc_key = symcrypto.aesgcm_decrypt(
        ss, bytes.fromhex(env["wrap_nonce_hex"]), bytes.fromhex(env["wrapped_key_hex"]))
    pdf_plain = symcrypto.aesgcm_decrypt(
        doc_key, bytes.fromhex(doc["doc_nonce_hex"]), store.load_blob(doc["ciphertext_file"]))

    chain = store.load_ledger()
    known_hashes = {b["event"].get("watermark_token_hash")
                    for b in chain if isinstance(b.get("event"), dict)}
    event_id = uuid.uuid4().hex
    # 128-bit opaque token, no identity inside; regenerate on the
    # astronomically unlikely event of a token-hash collision (dup prevention).
    for _ in range(10):
        token_hex = secrets.token_hex(16)
        token_hash = symcrypto.sha256_hex(bytes.fromhex(token_hex))
        if token_hash not in known_hashes:
            break
    else:
        raise RuntimeError("could not mint a fresh watermark token")

    # Same token generation/ledger/signing flow either way; only *which*
    # watermarking function embeds the token differs, chosen by the
    # document's own filename extension (set once, at encrypt_document time).
    text_mode = is_text_document(doc["filename"])
    if text_mode:
        watermarked = watermark_text.embed_text_watermark(
            pdf_plain.decode("utf-8"), token_hex).encode("utf-8")
    else:
        watermarked = watermark.embed_token(pdf_plain, token_hex)

    event = {
        "event_id": event_id,
        "recipient_id": recipient_id,
        "document_id": doc_id,
        "document_hash": symcrypto.sha256_hex(pdf_plain),
        "watermark_token_hash": token_hash,
        "timestamp": utcnow_iso(),
    }
    if text_mode:
        # Additive field only: carries the visible canary channel's prefix
        # so investigate_leak can look up a "canary-only" match (invisible
        # channel stripped) without ever needing the full token. ledger.py's
        # append_event/verify_ledger only require REQUIRED_EVENT_FIELDS and
        # otherwise pass any event dict through untouched, so this extra
        # field is included in — and covered by — the same ML-DSA signature
        # as everything else in `event`; no change to ledger.py itself.
        event["watermark_canary_prefix"] = token_hex[:watermark_text.CANARY_PREFIX_LEN]
    sig = pqc.dsa_sign(dsa_sk, ledger_mod.canonical(event))
    block = ledger_mod.append_event(chain, event, sig.hex(), recipient_id)
    store.save_ledger(chain)
    # NOTE: store.save_copy always writes under a ".pdf" filename regardless
    # of content type (store.py is intentionally left unmodified, per scope).
    # The bytes themselves are correct either way; only the on-disk filename
    # extension is cosmetically PDF-shaped for a .txt/.md copy.
    store.save_copy(event_id, watermarked)
    return {"event_id": event_id, "recipient_id": recipient_id, "doc_id": doc_id,
            "document_hash": event["document_hash"],
            "watermark_token_hash": event["watermark_token_hash"],
            "timestamp": event["timestamp"], "block_index": block["index"],
            "signature_hex": sig.hex(), "pdf_bytes": watermarked,
            "is_text": text_mode}


# ---- .txt/.md leak investigation (additive; PDF branch below is untouched) ----
def _looks_like_text(data: bytes) -> bool:
    try:
        data.decode("utf-8")
    except UnicodeDecodeError:
        return False
    return True


def _investigate_leak_text(leaked_bytes: bytes) -> dict:
    """Investigate a leaked .txt/.md file. Checks both watermark channels
    independently and reports one of three cases explicitly:
      a) invisible channel matches the ledger -> normal VERIFIED result
      b) invisible channel missing but the visible canary prefix matches a
         ledger event -> still VERIFIED, but flagged "channel: canary-only"
      c) both channels missing -> honest NOT VERIFIED, with a note that this
         is consistent with deliberate stripping or manual retyping and
         cannot be distinguished from an unrelated file
    """
    validate_text(leaked_bytes, field="leaked file")
    text = leaked_bytes.decode("utf-8")
    extracted = watermark_text.extract_text_watermark(text)
    invisible_token = extracted["invisible"]
    canary_prefix = extracted["canary"]
    chain = store.load_ledger()
    recips = store.load_recipients()

    def find_hit(matches):
        for block in chain:
            ev = block.get("event")
            if isinstance(ev, dict) and matches(ev):
                return block
        return None

    def report_for_hit(hit, token_hash):
        # Same signature/ledger verification as the PDF path (see below),
        # applied here to a hit found via either text channel.
        try:
            signer_pk = bytes.fromhex(recips[hit["signer"]]["dsa_pk_hex"])
            sig = bytes.fromhex(hit["signature"])
        except (KeyError, ValueError, TypeError):
            return {"match": False, "status": "NOT VERIFIED",
                    "reason": "matching event references unknown/malformed signer key",
                    "watermark": "MATCHED-UNVERIFIABLE", "watermark_token_hash": token_hash,
                    "conclusion": "No verified decryption event matches this file."}
        ok_sig = pqc.dsa_verify(signer_pk, ledger_mod.canonical(hit["event"]), sig)
        ok_chain, chain_msg = ledger_mod.verify_ledger(chain, recips)
        verified = bool(ok_sig and ok_chain)
        recipient = hit["event"]["recipient_id"]
        if not verified:
            return {"match": False, "status": "NOT VERIFIED",
                    "reason": "event found but cryptographic verification failed",
                    "recipient": recipient, "event_id": hit["event"]["event_id"],
                    "watermark": "MATCHED",
                    "mldsa_signature": "VALID" if ok_sig else "INVALID",
                    "ledger_integrity": "VALID" if ok_chain else f"INVALID: {chain_msg}",
                    "conclusion": "No verified decryption event matches this file."}
        return {
            "match": True,
            "status": "VERIFIED",
            "recipient": recipient,
            "event_id": hit["event"]["event_id"],
            "document_hash": hit["event"]["document_hash"],
            "timestamp": hit["event"]["timestamp"],
            "block_index": hit["index"],
            "watermark": "MATCHED",
            "watermark_token_hash": token_hash,
            "mldsa_signature": "VALID",
            "ledger_integrity": "VALID",
            "ledger_detail": chain_msg,
            "conclusion": (f"This document is cryptographically associated with "
                           f"{recipient}'s authorized decryption event."),
            "scope": {
                "cryptographic_attribution":
                    (f"The leaked copy carries the watermark of {recipient}'s signed "
                     "decryption event (watermark match + valid ML-DSA signature + "
                     "intact ledger). Identifies the authorized decryption event "
                     "associated with the leaked copy; does not establish who "
                     "physically transmitted the leak."),
                "physical_attribution":
                    ("Not established. The system does not prove who physically "
                     "transmitted or leaked the file — only which authorized "
                     "decryption event this copy corresponds to."),
            },
            "note": ("This proves the leaked copy corresponds to that recipient's "
                     "signed decryption event; it does not cryptographically prove "
                     "who physically transmitted the leak."),
        }

    # --- case (a): invisible channel present -> normal VERIFIED path ---
    if invisible_token is not None:
        token_hash = symcrypto.sha256_hex(bytes.fromhex(invisible_token))
        hit = find_hit(lambda ev: ev.get("watermark_token_hash") == token_hash)
        if hit is None:
            return {"match": False, "status": "NOT VERIFIED",
                    "reason": "watermark extracted but no ledger event matches",
                    "watermark": "EXTRACTED-NO-MATCH", "watermark_token_hash": token_hash,
                    "conclusion": "No verified decryption event matches this file."}
        return report_for_hit(hit, token_hash)

    # --- case (b): invisible channel missing, canary prefix present ---
    if canary_prefix is not None:
        hit = find_hit(lambda ev: ev.get("watermark_canary_prefix") == canary_prefix)
        if hit is None:
            return {"match": False, "status": "NOT VERIFIED",
                    "reason": "canary marker extracted but no ledger event matches",
                    "watermark": "EXTRACTED-NO-MATCH", "channel": "canary-only",
                    "canary_prefix": canary_prefix,
                    "conclusion": "No verified decryption event matches this file."}
        token_hash = hit["event"].get("watermark_token_hash")
        result = report_for_hit(hit, token_hash)
        if result.get("match"):
            result["channel"] = "canary-only"
            result["note"] = ("invisible watermark missing or stripped; visible canary "
                               "marker intact")
        return result

    # --- case (c): both channels missing ---
    return {"match": False, "status": "NOT VERIFIED",
            "reason": "no watermark extracted from leaked file",
            "watermark": "NOT FOUND",
            "note": ("no watermark channels found; consistent with deliberate stripping "
                      "or manual retyping — cannot distinguish from an unrelated file"),
            "conclusion": "No verified decryption event matches this file."}


# ---- leak investigation ----
def investigate_leak(pdf_bytes: bytes) -> dict:
    # Auto-detected by content: '%PDF' magic bytes keep going through the
    # original PDF path unchanged below; anything else that decodes as UTF-8
    # text is routed to the new dual-channel .txt/.md investigation instead
    # of being rejected outright (this is the only behavior change for
    # previously-unsupported input; real PDFs and non-UTF-8 binary garbage
    # both behave exactly as before).
    if not pdf_bytes.startswith(b"%PDF") and _looks_like_text(pdf_bytes):
        return _investigate_leak_text(pdf_bytes)
    validate_pdf(pdf_bytes, field="leaked file")
    token_hex = watermark.extract_token(pdf_bytes)
    if token_hex is None:
        return {"match": False, "status": "NOT VERIFIED",
                "reason": "no watermark extracted from leaked file",
                "watermark": "NOT FOUND",
                "conclusion": "No verified decryption event matches this file."}
    token_hash = symcrypto.sha256_hex(bytes.fromhex(token_hex))
    chain = store.load_ledger()
    recips = store.load_recipients()
    hit = None
    for block in chain:
        if isinstance(block.get("event"), dict) and \
                block["event"].get("watermark_token_hash") == token_hash:
            hit = block
            break
    if hit is None:
        return {"match": False, "status": "NOT VERIFIED",
                "reason": "watermark extracted but no ledger event matches",
                "watermark": "EXTRACTED-NO-MATCH", "watermark_token_hash": token_hash,
                "conclusion": "No verified decryption event matches this file."}
    # A damaged/foreign ledger entry must yield "no verified match", never an exception.
    try:
        signer_pk = bytes.fromhex(recips[hit["signer"]]["dsa_pk_hex"])
        sig = bytes.fromhex(hit["signature"])
    except (KeyError, ValueError, TypeError):
        return {"match": False, "status": "NOT VERIFIED",
                "reason": "matching event references unknown/malformed signer key",
                "watermark": "MATCHED-UNVERIFIABLE", "watermark_token_hash": token_hash,
                "conclusion": "No verified decryption event matches this file."}
    ok_sig = pqc.dsa_verify(signer_pk, ledger_mod.canonical(hit["event"]), sig)
    ok_chain, chain_msg = ledger_mod.verify_ledger(chain, recips)
    verified = bool(ok_sig and ok_chain)
    recipient = hit["event"]["recipient_id"]
    if not verified:
        return {"match": False, "status": "NOT VERIFIED",
                "reason": "event found but cryptographic verification failed",
                "recipient": recipient, "event_id": hit["event"]["event_id"],
                "watermark": "MATCHED",
                "mldsa_signature": "VALID" if ok_sig else "INVALID",
                "ledger_integrity": "VALID" if ok_chain else f"INVALID: {chain_msg}",
                "conclusion": "No verified decryption event matches this file."}
    return {
        "match": True,
        "status": "VERIFIED",
        "recipient": recipient,
        "event_id": hit["event"]["event_id"],
        "document_hash": hit["event"]["document_hash"],
        "timestamp": hit["event"]["timestamp"],
        "block_index": hit["index"],
        "watermark": "MATCHED",
        "watermark_token_hash": token_hash,
        "mldsa_signature": "VALID",
        "ledger_integrity": "VALID",
        "ledger_detail": chain_msg,
        "conclusion": (f"This document is cryptographically associated with "
                       f"{recipient}'s authorized decryption event."),
        "scope": {
            "cryptographic_attribution":
                (f"The leaked copy carries the watermark of {recipient}'s signed "
                 "decryption event (watermark match + valid ML-DSA signature + "
                 "intact ledger). Identifies the authorized decryption event "
                 "associated with the leaked copy; does not establish who "
                 "physically transmitted the leak."),
            "physical_attribution":
                ("Not established. The system does not prove who physically "
                 "transmitted or leaked the file — only which authorized "
                 "decryption event this copy corresponds to."),
        },
        "note": ("This proves the leaked copy corresponds to that recipient's "
                 "signed decryption event; it does not cryptographically prove "
                 "who physically transmitted the leak."),
    }