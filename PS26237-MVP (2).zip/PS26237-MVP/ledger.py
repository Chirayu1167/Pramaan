"""Local tamper-evident blockchain-style hash-chain ledger (offline).

This is a single-machine append-only audit log, NOT a distributed
blockchain: there is no consensus network, no peers, no cloud. Tamper
*evidence* comes from the SHA-256 hash chain plus an ML-DSA signature on
every block — any edit, reorder, truncation, or forgery is detected by
verify_ledger(). Tamper *prevention* at the OS/file level is out of scope.

Each block: {index, timestamp, event, signature, signer (recipient_id),
             prev_hash, block_hash}
block_hash = SHA256(canonical(block without 'block_hash')).
"""
import json
from datetime import datetime, timezone

import pqc
import symcrypto

GENESIS_PREV = "0" * 64


def utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def canonical(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")


def block_hash_of(block_without_hash: dict) -> str:
    return symcrypto.sha256_hex(canonical(block_without_hash))


REQUIRED_EVENT_FIELDS = ("event_id", "recipient_id", "document_id",
                           "document_hash", "watermark_token_hash", "timestamp")


def _event_ids(chain: list) -> tuple[set, set]:
    """Collect (event_ids, watermark_token_hashes) already on the chain."""
    eids, thashes = set(), set()
    for b in chain:
        ev = b.get("event") if isinstance(b, dict) else None
        if isinstance(ev, dict):
            if isinstance(ev.get("event_id"), str):
                eids.add(ev["event_id"])
            if isinstance(ev.get("watermark_token_hash"), str):
                thashes.add(ev["watermark_token_hash"])
    return eids, thashes


def append_event(chain: list, event: dict, signature_hex: str, signer_id: str) -> dict:
    """Append one block. Rejects malformed events and duplicates."""
    if not isinstance(event, dict) or \
            any(not isinstance(event.get(f), str) for f in REQUIRED_EVENT_FIELDS):
        raise ValueError("event must contain all required string fields: "
                         + ", ".join(REQUIRED_EVENT_FIELDS))
    if not isinstance(signature_hex, str) or not isinstance(signer_id, str):
        raise ValueError("signature and signer must be strings")
    eids, thashes = _event_ids(chain)
    if event["event_id"] in eids:
        raise ValueError(f"duplicate event_id {event['event_id']!r}: ledger is append-only")
    if event["watermark_token_hash"] in thashes:
        raise ValueError("duplicate watermark_token_hash: each decryption needs a fresh token")
    prev = chain[-1]["block_hash"] if chain else GENESIS_PREV
    block = {
        "index": len(chain),
        "timestamp": utcnow_iso(),
        "event": event,
        "signature": signature_hex,
        "signer": signer_id,
        "prev_hash": prev,
    }
    block["block_hash"] = block_hash_of(block)
    chain.append(block)
    return block


def _is_hex64(s) -> bool:
    return isinstance(s, str) and len(s) == 64 and all(c in "0123456789abcdef" for c in s)


def verify_ledger(chain: list, recipients: dict) -> tuple[bool, str]:
    """Recompute the hash chain and verify every ML-DSA signature."""
    if not isinstance(chain, list):
        return False, "ledger must be a list of blocks"
    if not isinstance(recipients, dict):
        return False, "recipients must be a dict"
    prev = GENESIS_PREV
    for i, block in enumerate(chain):
        if not isinstance(block, dict):
            return False, f"block {i}: malformed block (not an object)"
        if set(block) != {"index", "timestamp", "event", "signature",
                          "signer", "prev_hash", "block_hash"}:
            return False, f"block {i}: malformed block (bad fields)"
        if block.get("index") != i:
            return False, f"block {i}: bad index"
        if block.get("prev_hash") != prev:
            return False, f"block {i}: prev_hash mismatch (chain broken)"
        if not isinstance(block.get("event"), dict):
            return False, f"block {i}: malformed event"
        recomputed = block_hash_of({k: v for k, v in block.items() if k != "block_hash"})
        if recomputed != block.get("block_hash"):
            return False, f"block {i}: block_hash mismatch (record modified)"
        if not _is_hex64(block.get("prev_hash") if i else GENESIS_PREV):
            return False, f"block {i}: malformed prev_hash"
        signer = block.get("signer")
        recip = recipients.get(signer)
        if recip is None:
            return False, f"block {i}: unknown signer {signer!r}"
        try:
            sig = bytes.fromhex(block["signature"])
            pk = bytes.fromhex(recip["dsa_pk_hex"])
        except Exception:
            return False, f"block {i}: malformed signature/public key"
        if not pqc.dsa_verify(pk, canonical(block["event"]), sig):
            return False, f"block {i}: ML-DSA signature INVALID"
        prev = block["block_hash"]
    return True, f"OK: {len(chain)} block(s), hash chain + all ML-DSA signatures valid"
