﻿"""Local web UI for the PS26237 BASE MVP. Runs fully offline (Flask, no CDN)."""
import io
import re

from flask import Flask, jsonify, request, send_file, render_template

import core
import demo as demo_mod
import ledger as ledger_mod
import store

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024

LAST_INVESTIGATION: dict | None = None  # in-memory only, reset on restart
_HEX32 = re.compile(r"^[0-9a-f]{32}$")

@app.get("/")
def index():
    return render_template("index.html")


def last_inv_summary():
    if LAST_INVESTIGATION is None:
        return None
    return {"match": LAST_INVESTIGATION.get("match"),
            "recipient": LAST_INVESTIGATION.get("recipient"),
            "status": LAST_INVESTIGATION.get("status")}


@app.get("/api/status")
def status():
    try:
        recips = core.public_recipients()
        docs = store.load_documents()
        chain = store.load_ledger()
        ok, msg = ledger_mod.verify_ledger(chain, recips) if chain else (True, "ledger empty")
        return jsonify({
            "recipients": sorted(recips),
            "documents": [{"doc_id": d["doc_id"], "filename": d["filename"],
                           "document_hash": d["document_hash"]} for d in docs.values()],
            "decryption_events": len(chain),
            "ledger_valid": ok, "ledger_detail": msg,
            "last_investigation": last_inv_summary(),
        })
    except Exception as e:
        # e.g. corrupted JSON on disk: report as JSON, never an HTML 500 page
        return jsonify({"error": f"status unavailable: {type(e).__name__}: {e}"}), 500


@app.post("/api/init")
def init():
    try:
        return jsonify({"recipients": sorted(core.init_demo_recipients())})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.post("/api/encrypt")
def encrypt():
    try:
        f = request.files.get("file")
        if f is None:
            return jsonify({"error": "no file uploaded"}), 400
        data = f.read()
        return jsonify(core.encrypt_document(data, f.filename or "document.pdf"))
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.post("/api/decrypt")
def decrypt():
    try:
        body = request.get_json(force=True)
        doc_id, recipient_id = body.get("doc_id"), body.get("recipient_id")
        if not isinstance(doc_id, str) or not isinstance(recipient_id, str):
            return jsonify({"error": "doc_id and recipient_id must be strings"}), 400
        res = core.decrypt_for_recipient(doc_id, recipient_id)
        return jsonify({
            "event_id": res["event_id"], "recipient_id": res["recipient_id"],
            "doc_id": res["doc_id"], "document_hash": res["document_hash"],
            "watermark_token_hash": res["watermark_token_hash"],
            "timestamp": res["timestamp"], "block_index": res["block_index"],
            "signature": res["signature_hex"][:64] + "�",
            "download": f"/api/copy/{res['event_id']}",
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.post("/api/revoke")
def revoke():
    try:
        body = request.get_json(force=True)
        recipient_id, admin_id = body.get("recipient_id"), body.get("admin_id")
        passphrase = body.get("passphrase") or core.DEMO_PASSPHRASE
        if not isinstance(recipient_id, str) or not isinstance(admin_id, str):
            return jsonify({"error": "recipient_id and admin_id must be strings"}), 400
        _, admin_dsa_sk = store.load_private_keys(admin_id, passphrase)
        res = core.revoke_recipient(recipient_id, admin_id, admin_dsa_sk)
        return jsonify(res)
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.get("/api/copy/<event_id>")
def copy(event_id):
    if not _HEX32.match(event_id or ""):
        return jsonify({"error": "invalid event id"}), 404
    try:
        data = store.load_copy(event_id)
        return send_file(io.BytesIO(data), mimetype="application/pdf",
                         as_attachment=True, download_name=f"decrypted_{event_id[:8]}.pdf")
    except Exception:
        return jsonify({"error": "copy not found"}), 404


@app.get("/api/ledger")
def ledger_list():
    try:
        return jsonify(store.load_ledger())
    except Exception as e:
        return jsonify({"error": f"ledger unreadable: {type(e).__name__}: {e}"}), 500


@app.post("/api/verify")
def ledger_verify():
    try:
        chain = store.load_ledger()
        ok, msg = ledger_mod.verify_ledger(chain, store.load_recipients())
        return jsonify({"valid": ok, "detail": msg})
    except Exception as e:
        return jsonify({"valid": False, "detail": f"verify failed: {type(e).__name__}: {e}"})


@app.post("/api/investigate")
def investigate():
    global LAST_INVESTIGATION
    try:
        f = request.files.get("file")
        if f is None:
            return jsonify({"error": "no file uploaded"}), 400
        res = core.investigate_leak(f.read())
        LAST_INVESTIGATION = res
        return jsonify(res)
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.post("/api/demo")
def run_full_demo():
    """One-click demo: same run_demo() as the CLI; resets local state. Errors surface."""
    global LAST_INVESTIGATION
    try:
        out = demo_mod.run_demo()
        if out.get("ok"):
            LAST_INVESTIGATION = out["forensic"]
        return jsonify(out)
    except Exception as e:  # never hide a crash
        return jsonify({"ok": False, "steps": [], "error": f"{type(e).__name__}: {e}"}), 500


if __name__ == "__main__":
    store.ensure_dirs()
    app.run(host="127.0.0.1", port=5000, debug=False)
