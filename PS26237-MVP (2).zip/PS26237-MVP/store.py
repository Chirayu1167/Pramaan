# """Local JSON persistence. Private keys live here, never leave the server."""
# import json
# import os

# DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
# KEYS_DIR = os.path.join(DATA_DIR, "keys")
# DOCS_DIR = os.path.join(DATA_DIR, "docs")
# COPIES_DIR = os.path.join(DATA_DIR, "copies")
# RECIPIENTS_FILE = os.path.join(DATA_DIR, "recipients.json")
# DOCUMENTS_FILE = os.path.join(DATA_DIR, "documents.json")
# LEDGER_FILE = os.path.join(DATA_DIR, "ledger.json")


# def ensure_dirs() -> None:
#     for d in (DATA_DIR, KEYS_DIR, DOCS_DIR, COPIES_DIR):
#         os.makedirs(d, exist_ok=True)


# def _load_json(path: str, default):
#     if not os.path.exists(path):
#         return default
#     with open(path, "r", encoding="utf-8") as f:
#         return json.load(f)


# def _save_json(path: str, obj) -> None:
#     tmp = path + ".tmp"
#     with open(tmp, "w", encoding="utf-8") as f:
#         json.dump(obj, f, indent=2)
#     os.replace(tmp, path)


# # ---- recipients: {id: {kem_pk_hex, dsa_pk_hex, created_at}} (NO private keys) ----
# def load_recipients() -> dict:
#     ensure_dirs()
#     return _load_json(RECIPIENTS_FILE, {})


# def save_recipients(recips: dict) -> None:
#     ensure_dirs()
#     _save_json(RECIPIENTS_FILE, recips)


# # ---- private keys (server-side only, never returned by any API) ----
# def save_private_keys(recipient_id: str, kem_sk: bytes, dsa_sk: bytes) -> None:
#     ensure_dirs()
#     with open(os.path.join(KEYS_DIR, f"{recipient_id}_kem.sk"), "wb") as f:
#         f.write(kem_sk)
#     with open(os.path.join(KEYS_DIR, f"{recipient_id}_dsa.sk"), "wb") as f:
#         f.write(dsa_sk)


# def load_private_keys(recipient_id: str) -> tuple[bytes, bytes]:
#     with open(os.path.join(KEYS_DIR, f"{recipient_id}_kem.sk"), "rb") as f:
#         kem_sk = f.read()
#     with open(os.path.join(KEYS_DIR, f"{recipient_id}_dsa.sk"), "rb") as f:
#         dsa_sk = f.read()
#     return kem_sk, dsa_sk


# # ---- documents: {doc_id: {filename, document_hash, doc_nonce_hex,
# #                           doc_ciphertext_file, envelopes: {recip: {kem_ct_hex,
# #                           wrap_nonce_hex, wrapped_key_hex}}, created_at}} ----
# def load_documents() -> dict:
#     ensure_dirs()
#     return _load_json(DOCUMENTS_FILE, {})


# def save_documents(docs: dict) -> None:
#     ensure_dirs()
#     _save_json(DOCUMENTS_FILE, docs)


# def save_blob(filename: str, data: bytes) -> str:
#     """Save bytes under DOCS_DIR, return the stored filename."""
#     ensure_dirs()
#     path = os.path.join(DOCS_DIR, filename)
#     with open(path, "wb") as f:
#         f.write(data)
#     return filename


# def load_blob(filename: str) -> bytes:
#     with open(os.path.join(DOCS_DIR, filename), "rb") as f:
#         return f.read()


# # ---- watermarked copies: data/copies/<event_id>.pdf ----
# def save_copy(event_id: str, data: bytes) -> None:
#     ensure_dirs()
#     with open(os.path.join(COPIES_DIR, f"{event_id}.pdf"), "wb") as f:
#         f.write(data)


# def load_copy(event_id: str) -> bytes:
#     with open(os.path.join(COPIES_DIR, f"{event_id}.pdf"), "rb") as f:
#         return f.read()


# # ---- ledger ----
# # The ledger file is append-only through this API: a save must extend the
# # stored chain (same prefix), never rewrite or truncate history. Full resets
# # happen only by deleting data/ (demo/test reset path). Note this guards the
# # application path; OS-level file protection is out of scope — tampering is
# # *detected* by ledger.verify_ledger(), not prevented here.
# def load_ledger() -> list:
#     ensure_dirs()
#     return _load_json(LEDGER_FILE, [])


# def save_ledger(chain: list) -> None:
#     ensure_dirs()
#     if not isinstance(chain, list):
#         raise ValueError("ledger chain must be a list")
#     stored = _load_json(LEDGER_FILE, [])
#     if stored:
#         if len(chain) < len(stored) or chain[:len(stored)] != stored:
#             raise ValueError(
#                 "ledger is append-only: refusing to rewrite or truncate stored history")
#     _save_json(LEDGER_FILE, chain)


"""Local JSON persistence. Private keys live here, never leave the server."""
import json
import os
import secrets

from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

import symcrypto

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
KEYS_DIR = os.path.join(DATA_DIR, "keys")
DOCS_DIR = os.path.join(DATA_DIR, "docs")
COPIES_DIR = os.path.join(DATA_DIR, "copies")
RECIPIENTS_FILE = os.path.join(DATA_DIR, "recipients.json")
DOCUMENTS_FILE = os.path.join(DATA_DIR, "documents.json")
LEDGER_FILE = os.path.join(DATA_DIR, "ledger.json")

# ---- private-key-at-rest encryption: passphrase -> scrypt -> AES-256-GCM ----
SCRYPT_SALT_LEN = 16
SCRYPT_N = 2 ** 14
SCRYPT_R = 8
SCRYPT_P = 1
SCRYPT_KEY_LEN = 32  # AES-256


def ensure_dirs() -> None:
    for d in (DATA_DIR, KEYS_DIR, DOCS_DIR, COPIES_DIR):
        os.makedirs(d, exist_ok=True)


def _load_json(path: str, default):
    if not os.path.exists(path):
        return default
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _save_json(path: str, obj) -> None:
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)
    os.replace(tmp, path)


# ---- recipients: {id: {kem_pk_hex, dsa_pk_hex, created_at}} (NO private keys) ----
def load_recipients() -> dict:
    ensure_dirs()
    return _load_json(RECIPIENTS_FILE, {})


def save_recipients(recips: dict) -> None:
    ensure_dirs()
    _save_json(RECIPIENTS_FILE, recips)


# ---- private keys (server-side only, never returned by any API) ----
# Encrypted at rest: passphrase -> scrypt -> 32-byte key -> AES-256-GCM
# (symmetric only, same primitive as symcrypto's document encryption). Each
# key file is self-describing (kdf params + salt + nonce + ciphertext), so
# it can be decrypted from the passphrase alone with no other external state.
def _derive_key_from_passphrase(passphrase: str, salt: bytes, n: int, r: int, p: int) -> bytes:
    kdf = Scrypt(salt=salt, length=SCRYPT_KEY_LEN, n=n, r=r, p=p)
    return kdf.derive(passphrase.encode("utf-8"))


def _encrypt_key_blob(plaintext: bytes, passphrase: str) -> dict:
    salt = secrets.token_bytes(SCRYPT_SALT_LEN)
    key = _derive_key_from_passphrase(passphrase, salt, SCRYPT_N, SCRYPT_R, SCRYPT_P)
    nonce, ct = symcrypto.aesgcm_encrypt(key, plaintext)
    return {
        "kdf": "scrypt", "n": SCRYPT_N, "r": SCRYPT_R, "p": SCRYPT_P,
        "salt_hex": salt.hex(), "nonce_hex": nonce.hex(), "ciphertext_hex": ct.hex(),
    }


def _decrypt_key_blob(blob: dict, passphrase: str) -> bytes:
    try:
        salt = bytes.fromhex(blob["salt_hex"])
        nonce = bytes.fromhex(blob["nonce_hex"])
        ct = bytes.fromhex(blob["ciphertext_hex"])
        key = _derive_key_from_passphrase(passphrase, salt, blob["n"], blob["r"], blob["p"])
    except (KeyError, ValueError) as e:
        raise ValueError("corrupted private-key file") from e
    try:
        return symcrypto.aesgcm_decrypt(key, nonce, ct)
    except Exception as e:
        # AES-GCM auth failure means the passphrase was wrong (or the file
        # was tampered with) — either way, surface one clear error.
        raise ValueError("incorrect passphrase or corrupted private-key file") from e


def save_private_keys(recipient_id: str, kem_sk: bytes, dsa_sk: bytes, passphrase: str) -> None:
    if not passphrase:
        raise ValueError("passphrase is required to encrypt private keys")
    ensure_dirs()
    _save_json(os.path.join(KEYS_DIR, f"{recipient_id}_kem.sk"),
               _encrypt_key_blob(kem_sk, passphrase))
    _save_json(os.path.join(KEYS_DIR, f"{recipient_id}_dsa.sk"),
               _encrypt_key_blob(dsa_sk, passphrase))


def load_private_keys(recipient_id: str, passphrase: str) -> tuple[bytes, bytes]:
    if not passphrase:
        raise ValueError("passphrase is required to decrypt private keys")
    kem_blob = _load_json(os.path.join(KEYS_DIR, f"{recipient_id}_kem.sk"), None)
    dsa_blob = _load_json(os.path.join(KEYS_DIR, f"{recipient_id}_dsa.sk"), None)
    if kem_blob is None or dsa_blob is None:
        raise FileNotFoundError(f"no private keys stored for {recipient_id}")
    kem_sk = _decrypt_key_blob(kem_blob, passphrase)
    dsa_sk = _decrypt_key_blob(dsa_blob, passphrase)
    return kem_sk, dsa_sk


# ---- documents: {doc_id: {filename, document_hash, doc_nonce_hex,
#                           doc_ciphertext_file, envelopes: {recip: {kem_ct_hex,
#                           wrap_nonce_hex, wrapped_key_hex}}, created_at}} ----
def load_documents() -> dict:
    ensure_dirs()
    return _load_json(DOCUMENTS_FILE, {})


def save_documents(docs: dict) -> None:
    ensure_dirs()
    _save_json(DOCUMENTS_FILE, docs)


def save_blob(filename: str, data: bytes) -> str:
    """Save bytes under DOCS_DIR, return the stored filename."""
    ensure_dirs()
    path = os.path.join(DOCS_DIR, filename)
    with open(path, "wb") as f:
        f.write(data)
    return filename


def load_blob(filename: str) -> bytes:
    with open(os.path.join(DOCS_DIR, filename), "rb") as f:
        return f.read()


# ---- watermarked copies: data/copies/<event_id>.pdf ----
def save_copy(event_id: str, data: bytes) -> None:
    ensure_dirs()
    with open(os.path.join(COPIES_DIR, f"{event_id}.pdf"), "wb") as f:
        f.write(data)


def load_copy(event_id: str) -> bytes:
    with open(os.path.join(COPIES_DIR, f"{event_id}.pdf"), "rb") as f:
        return f.read()


# ---- ledger ----
# The ledger file is append-only through this API: a save must extend the
# stored chain (same prefix), never rewrite or truncate history. Full resets
# happen only by deleting data/ (demo/test reset path). Note this guards the
# application path; OS-level file protection is out of scope — tampering is
# *detected* by ledger.verify_ledger(), not prevented here.
def load_ledger() -> list:
    ensure_dirs()
    return _load_json(LEDGER_FILE, [])


def save_ledger(chain: list) -> None:
    ensure_dirs()
    if not isinstance(chain, list):
        raise ValueError("ledger chain must be a list")
    stored = _load_json(LEDGER_FILE, [])
    if stored:
        if len(chain) < len(stored) or chain[:len(stored)] != stored:
            raise ValueError(
                "ledger is append-only: refusing to rewrite or truncate stored history")
    _save_json(LEDGER_FILE, chain)