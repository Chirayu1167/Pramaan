# PS26237 — Cryptographic Attribution & Immutable Decryption Provenance (MVP)

**This MVP demonstrates cryptographic attribution of an authorized decryption event.
It does not prove who physically transmitted or leaked the document.**

One sensitive PDF is encrypted once and shared with several recipients. Each
recipient decrypts with their own key; at that moment the system embeds a unique
invisible watermark, signs the decryption record with the recipient's post-quantum
private key, and appends it to a tamper-evident local ledger. If a copy leaks, the
watermark is extracted and matched against the signed ledger to identify which
**decryption event** the copy came from.

## Architecture

```
Encrypt once (AES-256-GCM + one ML-KEM-768 envelope per recipient)
        ↓
Recipient-specific decryption (ML-KEM decaps → AES-GCM unwrap → AES-GCM decrypt)
        ↓
Unique invisible watermark (128-bit opaque token, PDF text layer, rendering mode 3)
        ↓
ML-DSA-65 signed event {event_id, recipient_id, document_hash,
                        watermark_token_hash, timestamp, document_id}
        ↓
Local tamper-evident blockchain-style hash-chain ledger (NOT distributed:
no consensus, no peers — SHA-256 linked, every block signature-verified)
        ↓
Leak investigation (extract watermark → match event → verify signature + ledger)
        ↓
Cryptographic recipient attribution (of the decryption event — see scope note)
```

Modules: `core.py` (flow), `pqc.py` (PQC wrappers), `symcrypto.py` (AES-GCM/SHA-256),
`watermark.py` (embed/extract), `ledger.py` (hash chain), `store.py` (local JSON +
server-side keys), `app.py` (Flask UI), `demo.py` (one-click demo + artifacts),
`test_mvp.py` (negative/positive checks).

## PS26237 requirement status (brief §2/§3/§5)

| Requirement | Status |
|---|---|
| Encrypt once, decrypt per recipient with own key | IMPLEMENTED |
| Invisible unique mark at the moment of decryption, not before | IMPLEMENTED |
| Mark tied to recipient identity via own private-key signature (non-repudiation) | IMPLEMENTED |
| NIST-approved PQC (ML-KEM for key access, ML-DSA for records), no classical crypto | IMPLEMENTED |
| Tamper-evident ledger: single admin cannot secretly rewrite history (edits detected) | IMPLEMENTED (local) |
| Leaked file → extract mark → ledger lookup → proof of who decrypted + when | IMPLEMENTED |
| Fully offline: no internet, no cloud services, no public blockchain, no cloud KMS | IMPLEMENTED |
| Simple dashboard running the whole flow end to end | IMPLEMENTED |
| Local key storage / offline identity setup (basic) | IMPLEMENTED |
| Multi-party threshold (2-of-3) sign-off on ledger records | FUTURE SCOPE* |
| Screenshot/compression-robust watermark + live screenshot demo | FUTURE SCOPE* |
| Image/scanned-page watermarking, print+re-scan, Office files | FUTURE SCOPE (brief §7) |
| Real multi-machine air-gapped deployment, HSM, military PKI | FUTURE SCOPE (brief §7) |

\* The brief lists threshold sign-off and screenshot robustness as "building",
but they are explicitly out of scope for this BASE MVP (no consensus network,
no DCT/image watermarking) and are classified honestly as future work.

## Security primitives

| Use | Primitive | Standard |
|---|---|---|
| Document encryption | AES-256-GCM (random key + fresh 96-bit nonce per encryption) | NIST SP 800-38D |
| Per-recipient key access | ML-KEM-768 encaps/decaps, shared secret as KEK (KEM-DEM hybrid) | FIPS 203 |
| Event signatures | ML-DSA-65 over canonical JSON | FIPS 204 |
| Ledger / commitments | SHA-256 (hash chain + `watermark_token_hash` + `document_hash`) | FIPS 180-4 |
| Randomness | `secrets` / `uuid4` / PQC reference RNG (OS entropy) | — |

No RSA/ECDSA/Diffie-Hellman anywhere. Canonical serialization (`sort_keys`, compact
separators) is used for every signed/hashed record. Private keys live in
`data/keys/` and are never returned by any API. Fully offline — no network, no
blockchain, no cloud.

## Installation

```
pip install -r requirements.txt
```

## Running the demo

```
python demo.py
```

Runs the full flow (init A/B/C → encrypt sample once → decrypt as A and B →
uniqueness proofs → investigate A's copy → ledger verify → tamper proof) and
writes judge-ready artifacts to `demo_output/` (`encrypted/`, `decrypted/`,
`investigation/`, `ledger/` — no private keys).

## Running tests

```
python test_mvp.py
```

25 checks: cross-envelope rejection, wrong-key failure, AES-GCM tamper rejection,
watermark/event/ledger/prev-hash tamper detection, fake-event rejection, A/B
uniqueness, single common ciphertext, A→A / B→B attribution, clean-PDF no-match,
wrong-recipient-key failure, invalid signer, malformed ledger, duplicate-append
rejection, ledger append-only enforcement, watermark-at-decryption proof,
API traversal/field validation, offline static scan, report wording,
ledger validity, no secret exposure.

## Running the UI

```
python app.py
```

Open http://127.0.0.1:5000 — Dashboard (pipeline + live status cards), Encrypt,
Decrypt, Ledger, Investigate, How-it-works, and a **RUN FULL DEMO** button that
executes the same `run_demo()` as the CLI (resets local state; errors surface).

## Example investigation result

```
FORENSIC MATCH

Status: VERIFIED
Recipient: RECIPIENT-A
Event ID: 94cfeeb8349d46fc92c0c6d683c4bb5a
Document Hash: 973640df…
Timestamp: 2026-09-25T15:13:15.190456+00:00

Watermark: MATCHED
ML-DSA Signature: VALID
Ledger Integrity: VALID

Conclusion:
This document is cryptographically associated with RECIPIENT-A's authorized
decryption event.

Scope — cryptographic vs physical attribution:
- The leaked copy carries the watermark of RECIPIENT-A's signed decryption
  event (watermark match + valid ML-DSA signature + intact ledger).
- Not established. The system does not prove who physically transmitted or
  leaked the file — only which authorized decryption event this copy
  corresponds to.
```

## OFFLINE / AIR-GAPPED OPERATION

Everything runs locally in one Python process; the test suite statically
verifies no source file imports networking or references remote endpoints:

- All cryptography is local: `pqcrypto` (compiled NIST reference code for
  ML-KEM-768 / ML-DSA-65), `cryptography` (AES-256-GCM), `hashlib` (SHA-256),
  OS entropy via `secrets`.
- Storage is local files under `data/` (JSON + key files + PDF copies).
- The ledger is a local hash chain — no public blockchain, no cloud
  blockchain, no external DLT, no peers.
- No cloud KMS, no external auth, no external API, no online crypto service.
- The Flask UI binds to `127.0.0.1` only and loads no CDN resources.
- Dependencies are installed once (`pip install`); after that the demo,
  tests, and UI run with network access disabled.

## CURRENT MVP (implemented)

- PDF documents only.
- ML-KEM-768 per-recipient key envelopes + AES-256-GCM single ciphertext.
- ML-DSA-65 signed decryption events over canonical JSON.
- Invisible PDF text-layer watermark (rendering-mode-3), unique 128-bit
  opaque token per decryption, embedded at decryption time.
- Local tamper-evident blockchain-style hash-chain ledger (NOT distributed).
- Offline forensic extraction + signature/ledger verification.
- Local Flask demo UI + one-click demo + `demo_output/` artifacts.

## Current MVP limitations

- Watermark is invisible in normal PDF rendering but does not survive
  screenshot / JPEG recompression / print-scan.
- Ledger detects tampering but cannot prevent OS-level file edits; history
  is append-only through the application API only.
- No threshold sign-off, no HSM; keys are local files.
- PDF only.

## FUTURE / PRODUCTION EXTENSIONS (not implemented)

- Screenshot-resistant DCT/luminance watermarking + measured robustness numbers.
- JPEG/compression and print-scan resistance.
- Image / scanned-document support.
- Office document (Word/PowerPoint/Excel) support.
- Distributed DLT / multi-custodian (2-of-3) consensus ledger.
- HSM-backed key storage.
- Real multi-machine air-gapped deployment.
- Military PKI integration.
